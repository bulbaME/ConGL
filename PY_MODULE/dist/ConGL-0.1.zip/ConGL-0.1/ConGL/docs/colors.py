''' colors '''

FG_RED : int
FG_GREEN : int
FG_BLUE : int
FG_BLACK : int
FG_WHITE : int
FG_INTENSE : int

BG_RED : int
BG_GREEN : int
BG_BLUE : int
BG_BLACK : int
BG_WHITE : int
BG_INTENSE : int

UNDERSCORE : int