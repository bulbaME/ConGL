def down(ch : str) -> bool:
    ''' 
    verifies if key is down
    '''
    
def released(ch : str) -> bool:
    ''' 
    verifies if key was released
    '''
    
CAPS_ON : str
ALT_LEFT : str
ALT_RIGHT : str
CTRL_LEFT : str
CTRL_RIGHT : str
SHIFT : str