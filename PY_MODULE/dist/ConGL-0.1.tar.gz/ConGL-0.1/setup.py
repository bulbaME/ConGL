from distutils.core import setup
setup(
  name = 'ConGL',         
  packages = ['ConGL'],  
  version = '0.1',      
  license='MIT',        
  description = 'Console Graphics Library',  
  author = 'bulba',
  url = 'https://github.com/bulbaME/ConGL', 
  download_url = '', 
  keywords = ['console', 'cmd', 'engine', 'congl', 'terminal'], 
  install_requires=[ ],
  classifiers=[
    'Intended Audience :: Developers',
    'Topic :: Software Development :: Engine',
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 3.6',
    'Programming Language :: Python :: 3.7',
    'Programming Language :: Python :: 3.8',
    'Programming Language :: Python :: 3.9',
    'Programming Language :: Python :: 3.10'
  ],
)